package com.example.myapplication;

import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ManagerDB {

    public static FirebaseDatabase database = FirebaseDatabase.getInstance();
    static DatabaseReference myRef = database.getReference("User");
    static ArrayList<User> list;
    static User user;


    public ManagerDB() {

    }

    public static FirebaseDatabase getInstance() {
        return database.getInstance();
    }

    public static DatabaseReference getRef(String key) {
        return myRef = database.getReference(key);
    }



    public static Boolean getUserByEmail(String email) {
        readFromDatabase();
        if (list == null) {
            return false;
        }
        else {
            boolean hasDuplicate = false;
            for (int i = 0; i < list.size(); i++) {
                String email1 = list.get(i).getEmail();
                String email2 = email;
                if (email1.equals(email2))
                    hasDuplicate = true;
            }
            if (hasDuplicate) {
                return true;
            }
            return false;
        }


    }


    public static Boolean setUser(User u) //make bool
    {
        if (list == null) {
            list = new ArrayList<User>();
            list.add(u);
            myRef.child("data").setValue(list);
            return true;
        }

        boolean hasDuplicate = false;
        for (int i = 0; i < list.size(); i++) {
            String email1 = list.get(i).getEmail();
            String email2 = u.getEmail();
            if (email1.equals(email2))
                hasDuplicate = true;
        }
        if (!hasDuplicate) {
            list.add(u);
            myRef.child("data").setValue(list);
        }


        return false;
    }

    public static void readFromDatabase() {
        myRef.child("data").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list = new ArrayList<>();
                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                    User user = userSnapshot.getValue(User.class);
                    list.add(user);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}
