package com.example.myapplication;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class Ongoing_Task_screen extends AppCompatActivity implements View.OnClickListener {

    // Pass in intent the task list!!!!
    Intent intent,intent2;
    Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ongoing_task_screen);


        intent = getIntent();
        intent2 = new  Intent(this, MainScreen.class);
        btnBack = findViewById(R.id.btnBack);
btnBack.setOnClickListener(this);
        // Lookup the recyclerview in activity layout
        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        if (recyclerView == null) {
            Log.e("Ongoing_Task_screen", "RecyclerView is null");
            return;
        }

        // Use the correct key "TASKLIST" to retrieve the ArrayList from the intent
        ArrayList<Task> taskList = (ArrayList<Task>) intent.getSerializableExtra("TASKLIST");

        // Ensure taskList is not null
        if (taskList != null) {
            // Create adapter passing in the sample user data
            TaskAdapter adapter = new TaskAdapter(taskList);

            // Attach the adapter to the recyclerview to populate items
            recyclerView.setAdapter(adapter);

            // Set layout manager to position the items
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
        } else {
            Log.e("Ongoing_Task_screen", "TaskList is null");
            // Log an error or handle the case where taskList is null
        }
    }

    @Override
    public void onClick(View view) {
        if (view == btnBack) {
            // Start the second activity for a result
            startActivityForResult(intent2,0);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


    }
}