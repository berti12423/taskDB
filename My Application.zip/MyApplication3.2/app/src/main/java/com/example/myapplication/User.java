package com.example.myapplication;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class User implements Serializable {

    private String  username;
    private int level;
    String email;
    String password;
    public ArrayList<Task> tasklist;

    public ArrayList<Task> Getarray()
    {
        return this.tasklist;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
    public  ArrayList<Task> getTasklist() {
        return tasklist;
    }

    public User(String username, String password, String email) {
        this.tasklist = new ArrayList<>();
        this.level = 0;
        this.username = username;
        this.email = email;
        this.password = password;
    }
    public void SortList(ArrayList<Task> a) {   }
    public void  AddToList(Task t)
    {
        this.tasklist.add(t);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }



}
